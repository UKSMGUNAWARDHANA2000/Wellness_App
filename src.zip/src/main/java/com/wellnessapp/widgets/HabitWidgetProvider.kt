package com.wellnessapp.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.wellnessapp.MainActivity
import com.wellnessapp.R
import com.wellnessapp.utils.PreferencesManager

/**
 * HabitWidgetProvider - Home screen widget showing today's habit completion
 */
class HabitWidgetProvider : AppWidgetProvider() {
    
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Update all widget instances
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }
    
    override fun onEnabled(context: Context) {
        // Enter relevant functionality for when the first widget is created
    }
    
    override fun onDisabled(context: Context) {
        // Enter relevant functionality for when the last widget is disabled
    }
    
    companion object {
        fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val preferencesManager = PreferencesManager(context)
            val completionPercentage = preferencesManager.getTodayHabitCompletion()
            val habitsCount = preferencesManager.getHabitsCount()
            val habits = preferencesManager.getHabits()
            val completedHabits = habits.count { it.isCompleted }
            
            // Create intent to open main app
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            // Construct the RemoteViews object
            val views = RemoteViews(context.packageName, R.layout.habit_widget).apply {
                setTextViewText(R.id.widget_title, "Today's Habits")
                setTextViewText(R.id.widget_percentage, "$completionPercentage%")
                setTextViewText(R.id.widget_progress_text, "$completedHabits/$habitsCount completed")
                setProgressBar(R.id.widget_progress_circle, 100, completionPercentage, false)
                
                // Set click listener to open app
                setOnClickPendingIntent(R.id.widget_container, pendingIntent)
                
                // Set progress bar color based on completion
                val progressColor = when {
                    completionPercentage >= 80 -> android.R.color.holo_green_dark
                    completionPercentage >= 50 -> android.R.color.holo_orange_dark
                    else -> android.R.color.holo_red_dark
                }
                setInt(R.id.widget_progress_circle, "setProgressTintList", progressColor)
            }
            
            // Instruct the widget manager to update the widget
            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
        
        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(
                android.content.ComponentName(context, HabitWidgetProvider::class.java)
            )
            
            for (appWidgetId in appWidgetIds) {
                updateAppWidget(context, appWidgetManager, appWidgetId)
            }
        }
    }
}

