package com.wellnessapp.utils

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import kotlin.math.sqrt

/**
 * SensorManager for step counting and shake detection
 */
class WellnessSensorManager(
    private val context: Context,
    private val listener: SensorListener
) : SensorEventListener {
    
    interface SensorListener {
        fun onStepDetected(totalSteps: Int)
        fun onShakeDetected()
    }
    
    private val sensorManager: SensorManager = 
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    
    private var stepCounterSensor: Sensor? = null
    private var accelerometerSensor: Sensor? = null
    
    // Step counter variables
    private var initialStepCount = -1
    private var currentSteps = 0
    
    // Shake detection variables
    private var lastShakeTime = 0L
    private val shakeThreshold = 12.0f
    private val shakeInterval = 2000L // 2 seconds between shakes
    
    // Accelerometer data for shake detection
    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    private var lastUpdate = 0L
    
    init {
        initializeSensors()
    }
    
    private fun initializeSensors() {
        // Initialize step counter sensor
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        
        // Initialize accelerometer for shake detection if step counter not available
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }
    
    fun startListening() {
        // Start step counter if available
        stepCounterSensor?.let { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        
        // Start accelerometer for shake detection
        accelerometerSensor?.let { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
        }
    }
    
    fun stopListening() {
        sensorManager.unregisterListener(this)
    }
    
    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_STEP_COUNTER -> {
                handleStepCounter(event)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                handleAccelerometer(event)
            }
        }
    }
    
    private fun handleStepCounter(event: SensorEvent) {
        val stepCount = event.values[0].toInt()
        
        if (initialStepCount == -1) {
            initialStepCount = stepCount
            currentSteps = 0
        } else {
            currentSteps = stepCount - initialStepCount
        }
        
        listener.onStepDetected(currentSteps)
    }
    
    private fun handleAccelerometer(event: SensorEvent) {
        val currentTime = System.currentTimeMillis()
        
        if (currentTime - lastUpdate > 100) { // Check every 100ms
            val diffTime = currentTime - lastUpdate
            lastUpdate = currentTime
            
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            
            if (lastUpdate != 0L) {
                val speed = sqrt(
                    ((x - lastX) * (x - lastX) +
                    (y - lastY) * (y - lastY) +
                    (z - lastZ) * (z - lastZ)).toDouble()
                ) / diffTime * 10000
                
                if (speed > shakeThreshold) {
                    detectShake(currentTime)
                }
            }
            
            lastX = x
            lastY = y
            lastZ = z
        }
    }
    
    private fun detectShake(currentTime: Long) {
        if (currentTime - lastShakeTime > shakeInterval) {
            lastShakeTime = currentTime
            
            // Post to main thread
            Handler(Looper.getMainLooper()).post {
                listener.onShakeDetected()
            }
        }
    }
    
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not used for this implementation
    }
    
    fun resetStepCount() {
        initialStepCount = -1
        currentSteps = 0
    }
    
    fun isStepCounterAvailable(): Boolean {
        return stepCounterSensor != null
    }
    
    fun isAccelerometerAvailable(): Boolean {
        return accelerometerSensor != null
    }
}