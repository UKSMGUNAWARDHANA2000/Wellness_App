package com.wellnessapp.utils

import android.content.Context
import android.content.SharedPreferences
import com.wellnessapp.models.Habit
import com.wellnessapp.models.MoodEntry
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * PreferencesManager - Handles all SharedPreferences operations for the app
 * Manages data persistence for habits, mood entries, and app settings
 */
class PreferencesManager(context: Context) {
    
    companion object {
        private const val PREFS_NAME = "wellness_app_prefs"
        private const val KEY_HABITS = "habits"
        private const val KEY_MOOD_ENTRIES = "mood_entries"
        private const val KEY_HYDRATION_REMINDER_ENABLED = "hydration_reminder_enabled"
        private const val KEY_HYDRATION_INTERVAL = "hydration_interval"
        private const val KEY_FIRST_LAUNCH = "first_launch"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_DAILY_WATER_GOAL = "daily_water_goal"
        private const val KEY_WATER_INTAKE_TODAY = "water_intake_today"
        private const val KEY_LAST_WATER_DATE = "last_water_date"
        
        // Default habits
        private val DEFAULT_HABITS = listOf(
            "Drink 8 glasses of water",
            "Exercise for 30 minutes",
            "Meditate for 10 minutes",
            "Take 10,000 steps",
            "Read for 20 minutes",
            "Get 8 hours of sleep",
            "Eat 5 servings of fruits/vegetables",
            "Practice gratitude",
            "Limit screen time",
            "Deep breathing exercises"
        )
    }
    
    private val sharedPreferences: SharedPreferences = 
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    
    // First launch and setup
    fun isFirstLaunch(): Boolean {
        return sharedPreferences.getBoolean(KEY_FIRST_LAUNCH, true)
    }
    
    fun setFirstLaunchCompleted() {
        sharedPreferences.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
    }
    
    // User settings
    fun setUserName(name: String) {
        sharedPreferences.edit().putString(KEY_USER_NAME, name).apply()
    }
    
    fun getUserName(): String {
        return sharedPreferences.getString(KEY_USER_NAME, "User") ?: "User"
    }
    
    // Habit Management
    fun saveHabits(habits: List<Habit>) {
        val habitsJson = habits.joinToString("|") { habit ->
            "${habit.id}~~~${habit.name}~~~${habit.isCompleted}~~~${habit.dateCreated}~~~${habit.lastCompletedDate ?: ""}"
        }
        sharedPreferences.edit().putString(KEY_HABITS, habitsJson).apply()
    }
    
    fun getHabits(): List<Habit> {
        val habitsString = sharedPreferences.getString(KEY_HABITS, "") ?: ""
        if (habitsString.isEmpty()) {
            // Initialize with default habits if none exist
            val defaultHabits = DEFAULT_HABITS.mapIndexed { index, name ->
                Habit(
                    id = index + 1,
                    name = name,
                    isCompleted = false,
                    dateCreated = getCurrentDate()
                )
            }
            saveHabits(defaultHabits)
            return defaultHabits
        }
        
        return habitsString.split("|").mapNotNull { habitString ->
            val parts = habitString.split("~~~")
            if (parts.size >= 4) {
                Habit(
                    id = parts[0].toIntOrNull() ?: 0,
                    name = parts[1],
                    isCompleted = parts[2].toBoolean(),
                    dateCreated = parts[3],
                    lastCompletedDate = if (parts.size > 4 && parts[4].isNotEmpty()) parts[4] else null
                )
            } else null
        }
    }
    
    fun addHabit(habitName: String) {
        val habits = getHabits().toMutableList()
        val newHabit = Habit(
            id = (habits.maxByOrNull { it.id }?.id ?: 0) + 1,
            name = habitName,
            isCompleted = false,
            dateCreated = getCurrentDate()
        )
        habits.add(newHabit)
        saveHabits(habits)
    }
    
    fun updateHabitCompletion(habitId: Int, isCompleted: Boolean) {
        val habits = getHabits().toMutableList()
        val habitIndex = habits.indexOfFirst { it.id == habitId }
        if (habitIndex != -1) {
            habits[habitIndex] = habits[habitIndex].copy(
                isCompleted = isCompleted,
                lastCompletedDate = if (isCompleted) getCurrentDate() else null
            )
            saveHabits(habits)
        }
    }
    
    fun deleteHabit(habitId: Int) {
        val habits = getHabits().toMutableList()
        habits.removeAll { it.id == habitId }
        saveHabits(habits)
    }
    
    fun getTodayHabitCompletion(): Int {
        val habits = getHabits()
        if (habits.isEmpty()) return 0
        val completedCount = habits.count { it.isCompleted }
        return (completedCount * 100) / habits.size
    }
    
    fun getHabitsCount(): Int {
        return getHabits().size
    }
    
    // Mood Entry Management
    fun saveMoodEntries(moodEntries: List<MoodEntry>) {
        val moodJson = moodEntries.joinToString("|") { mood ->
            "${mood.id}~~~${mood.emoji}~~~${mood.note}~~~${mood.timestamp}~~~${mood.moodLevel}"
        }
        sharedPreferences.edit().putString(KEY_MOOD_ENTRIES, moodJson).apply()
    }
    
    fun getMoodEntries(): List<MoodEntry> {
        val moodString = sharedPreferences.getString(KEY_MOOD_ENTRIES, "") ?: ""
        if (moodString.isEmpty()) return emptyList()
        
        return moodString.split("|").mapNotNull { moodString ->
            val parts = moodString.split("~~~")
            if (parts.size >= 5) {
                MoodEntry(
                    id = parts[0].toIntOrNull() ?: 0,
                    emoji = parts[1],
                    note = parts[2],
                    timestamp = parts[3],
                    moodLevel = parts[4].toIntOrNull() ?: 3
                )
            } else null
        }.sortedByDescending { it.timestamp }
    }
    
    fun addMoodEntry(emoji: String, note: String, moodLevel: Int) {
        val moodEntries = getMoodEntries().toMutableList()
        val newMoodEntry = MoodEntry(
            id = (moodEntries.maxByOrNull { it.id }?.id ?: 0) + 1,
            emoji = emoji,
            note = note,
            timestamp = getCurrentDateTime(),
            moodLevel = moodLevel
        )
        moodEntries.add(0, newMoodEntry) // Add at beginning for latest first
        saveMoodEntries(moodEntries)
    }
    
    fun deleteMoodEntry(moodId: Int) {
        val moodEntries = getMoodEntries().toMutableList()
        moodEntries.removeAll { it.id == moodId }
        saveMoodEntries(moodEntries)
    }
    
    fun getMoodEntriesCount(): Int {
        return getMoodEntries().size
    }
    
    // Hydration Management
    fun setHydrationReminderEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_HYDRATION_REMINDER_ENABLED, enabled).apply()
    }
    
    fun isHydrationReminderEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_HYDRATION_REMINDER_ENABLED, false)
    }
    
    fun setHydrationInterval(intervalMinutes: Int) {
        sharedPreferences.edit().putInt(KEY_HYDRATION_INTERVAL, intervalMinutes).apply()
    }
    
    fun getHydrationInterval(): Int {
        return sharedPreferences.getInt(KEY_HYDRATION_INTERVAL, 120) // Default 2 hours
    }
    
    fun setDailyWaterGoal(glasses: Int) {
        sharedPreferences.edit().putInt(KEY_DAILY_WATER_GOAL, glasses).apply()
    }
    
    fun getDailyWaterGoal(): Int {
        return sharedPreferences.getInt(KEY_DAILY_WATER_GOAL, 8) // Default 8 glasses
    }
    
    fun addWaterIntake() {
        val today = getCurrentDate()
        val lastWaterDate = sharedPreferences.getString(KEY_LAST_WATER_DATE, "")
        
        if (lastWaterDate != today) {
            // Reset water intake for new day
            sharedPreferences.edit()
                .putInt(KEY_WATER_INTAKE_TODAY, 1)
                .putString(KEY_LAST_WATER_DATE, today)
                .apply()
        } else {
            // Increment today's water intake
            val currentIntake = sharedPreferences.getInt(KEY_WATER_INTAKE_TODAY, 0)
            sharedPreferences.edit().putInt(KEY_WATER_INTAKE_TODAY, currentIntake + 1).apply()
        }
    }
    
    fun getTodayWaterIntake(): Int {
        val today = getCurrentDate()
        val lastWaterDate = sharedPreferences.getString(KEY_LAST_WATER_DATE, "")
        
        return if (lastWaterDate == today) {
            sharedPreferences.getInt(KEY_WATER_INTAKE_TODAY, 0)
        } else {
            0 // New day, reset to 0
        }
    }
    
    fun resetDailyProgress() {
        // Reset habit completion for new day
        val habits = getHabits().map { it.copy(isCompleted = false) }
        saveHabits(habits)
    }
    
    // Utility methods
    private fun getCurrentDate(): String {
        return dateFormat.format(Date())
    }
    
    private fun getCurrentDateTime(): String {
        return dateTimeFormat.format(Date())
    }
    
    // Get week mood data for charts
    fun getWeekMoodData(): List<Pair<String, Float>> {
        val moodEntries = getMoodEntries()
        val weekData = mutableListOf<Pair<String, Float>>()
        val calendar = Calendar.getInstance()
        
        // Get last 7 days
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            val dayString = dateFormat.format(calendar.time)
            
            val dayMoods = moodEntries.filter { entry ->
                entry.timestamp.startsWith(dayString)
            }
            
            val averageMood = if (dayMoods.isNotEmpty()) {
                dayMoods.map { it.moodLevel }.average().toFloat()
            } else {
                0f
            }
            
            val dayLabel = SimpleDateFormat("EEE", Locale.getDefault()).format(calendar.time)
            weekData.add(Pair(dayLabel, averageMood))
        }
        
        return weekData
    }
}