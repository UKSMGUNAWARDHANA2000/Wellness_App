package com.wellnessapp.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.wellnessapp.utils.HydrationReminderManager
import com.wellnessapp.utils.PreferencesManager

/**
 * BootReceiver - Restores alarms after device boot
 */
class BootReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            
            val preferencesManager = PreferencesManager(context)
            
            // Restore hydration reminders if they were enabled
            if (preferencesManager.isHydrationReminderEnabled()) {
                val hydrationManager = HydrationReminderManager(context)
                hydrationManager.scheduleHydrationReminders()
            }
        }
    }
}