package com.wellnessapp.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.wellnessapp.utils.HydrationReminderManager

/**
 * HydrationReminderReceiver - Handles hydration reminder alarms and actions
 */
class HydrationReminderReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        val hydrationManager = HydrationReminderManager(context)
        
        when (intent.action) {
            "DRINK_WATER_ACTION" -> {
                // User clicked "I drank water" in notification
                hydrationManager.recordWaterIntake()
                
                // Schedule next reminder
                hydrationManager.scheduleHydrationReminders()
            }
            else -> {
                // Regular alarm trigger
                hydrationManager.showHydrationNotification()
                
                // Schedule next reminder
                hydrationManager.scheduleHydrationReminders()
            }
        }
    }
}