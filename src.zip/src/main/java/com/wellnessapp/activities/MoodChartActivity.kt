package com.wellnessapp.activities

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.wellnessapp.databinding.ActivityMoodChartBinding
import com.wellnessapp.utils.PreferencesManager

/**
 * MoodChartActivity - Displays mood trends using MPAndroidChart
 */
class MoodChartActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMoodChartBinding
    private lateinit var preferencesManager: PreferencesManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoodChartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferencesManager = PreferencesManager(this)
        
        setupToolbar()
        setupChart()
        loadMoodData()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Mood Trends"
    }
    
    private fun setupChart() {
        binding.moodChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            setDrawGridBackground(false)
            
            // Configure X axis
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                isGranularityEnabled = true
            }
            
            // Configure left Y axis
            axisLeft.apply {
                setDrawGridLines(true)
                axisMaximum = 5f
                axisMinimum = 0f
                granularity = 1f
                isGranularityEnabled = true
            }
            
            // Disable right Y axis
            axisRight.isEnabled = false
            
            // Configure legend
            legend.isEnabled = true
        }
    }
    
    private fun loadMoodData() {
        val weekMoodData = preferencesManager.getWeekMoodData()
        
        if (weekMoodData.isEmpty()) {
            binding.textNoData.visibility = android.view.View.VISIBLE
            binding.moodChart.visibility = android.view.View.GONE
            return
        }
        
        binding.textNoData.visibility = android.view.View.GONE
        binding.moodChart.visibility = android.view.View.VISIBLE
        
        // Prepare data for chart
        val entries = mutableListOf<Entry>()
        val labels = mutableListOf<String>()
        
        weekMoodData.forEachIndexed { index, (dayLabel, moodValue) ->
            entries.add(Entry(index.toFloat(), moodValue))
            labels.add(dayLabel)
        }
        
        // Create dataset
        val dataSet = LineDataSet(entries, "Mood Level").apply {
            color = Color.parseColor("#2196F3")
            setCircleColor(Color.parseColor("#2196F3"))
            lineWidth = 3f
            circleRadius = 6f
            setDrawCircleHole(false)
            valueTextSize = 12f
            setDrawFilled(true)
            fillColor = Color.parseColor("#64B5F6")
            fillAlpha = 50
        }
        
        // Set data to chart
        val lineData = LineData(dataSet)
        binding.moodChart.data = lineData
        
        // Set custom labels for X axis
        binding.moodChart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        
        // Refresh chart
        binding.moodChart.invalidate()
        
        // Show statistics
        showMoodStatistics(weekMoodData)
    }
    
    private fun showMoodStatistics(weekData: List<Pair<String, Float>>) {
        val moodValues = weekData.map { it.second }.filter { it > 0 }
        
        if (moodValues.isNotEmpty()) {
            val averageMood = moodValues.average()
            val maxMood = moodValues.maxOrNull() ?: 0f
            val minMood = moodValues.minOrNull() ?: 0f
            
            val statsText = """
                📊 This Week's Mood Statistics:
                
                Average Mood: ${String.format("%.1f", averageMood)}/5.0
                Highest Mood: ${String.format("%.1f", maxMood)}/5.0
                Lowest Mood: ${String.format("%.1f", minMood)}/5.0
                Days Logged: ${moodValues.size}/7
            """.trimIndent()
            
            binding.textMoodStats.text = statsText
            binding.textMoodStats.visibility = android.view.View.VISIBLE
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}