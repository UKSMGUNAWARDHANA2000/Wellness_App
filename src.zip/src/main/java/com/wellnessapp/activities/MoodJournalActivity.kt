package com.wellnessapp.activities

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.wellnessapp.R
import com.wellnessapp.adapters.MoodAdapter
import com.wellnessapp.databinding.ActivityMoodJournalBinding
import com.wellnessapp.models.MoodEntry
import com.wellnessapp.utils.PreferencesManager

/**
 * MoodJournalActivity - Manages mood tracking with emoji selector
 * Features: Add mood entries with emojis, view mood history, and delete entries
 */
class MoodJournalActivity : AppCompatActivity(), MoodAdapter.OnMoodInteractionListener {
    
    private lateinit var binding: ActivityMoodJournalBinding
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var moodAdapter: MoodAdapter
    private var moodEntries = mutableListOf<MoodEntry>()
    
    // Mood options with emojis and levels
    private val moodOptions = listOf(
        Triple("😭", "Very Sad", 1),
        Triple("😢", "Sad", 2),
        Triple("😐", "Neutral", 3),
        Triple("😊", "Happy", 4),
        Triple("😄", "Very Happy", 5)
    )
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoodJournalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferencesManager = PreferencesManager(this)
        
        setupToolbar()
        setupRecyclerView()
        setupFab()
        loadMoodEntries()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Mood Journal"
    }
    
    private fun setupRecyclerView() {
        moodAdapter = MoodAdapter(moodEntries, this)
        binding.recyclerViewMoods.apply {
            layoutManager = LinearLayoutManager(this@MoodJournalActivity)
            adapter = moodAdapter
        }
    }
    
    private fun setupFab() {
        binding.fabAddMood.setOnClickListener {
            showAddMoodDialog()
        }
    }
    
    private fun loadMoodEntries() {
        moodEntries.clear()
        moodEntries.addAll(preferencesManager.getMoodEntries())
        moodAdapter.notifyDataSetChanged()
        
        // Show empty state if no mood entries
        if (moodEntries.isEmpty()) {
            binding.layoutMoodEmptyState.visibility = android.view.View.VISIBLE
            binding.recyclerViewMoods.visibility = android.view.View.GONE
        } else {
            binding.layoutMoodEmptyState.visibility = android.view.View.GONE
            binding.recyclerViewMoods.visibility = android.view.View.VISIBLE
        }
        
        updateStatsDisplay()
    }
    
    private fun updateStatsDisplay() {
        val totalEntries = moodEntries.size
        binding.textTotalEntries.text = "Total entries: $totalEntries"
        
        if (totalEntries > 0) {
            val averageMood = moodEntries.map { it.moodLevel }.average()
            val averageMoodText = when {
                averageMood >= 4.5 -> "Very Happy 😄"
                averageMood >= 3.5 -> "Happy 😊"
                averageMood >= 2.5 -> "Neutral 😐"
                averageMood >= 1.5 -> "Sad 😢"
                else -> "Very Sad 😭"
            }
            binding.textAverageMood.text = "Average mood: $averageMoodText"
        } else {
            binding.textAverageMood.text = "No mood data yet"
        }
    }
    
    private fun showAddMoodDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_mood, null)
        val radioGroup = dialogView.findViewById<RadioGroup>(R.id.radio_group_moods)
        val editTextNote = dialogView.findViewById<EditText>(R.id.edit_text_note)
        
        // Add mood options to radio group
        moodOptions.forEachIndexed { index, (emoji, label, level) ->
            val radioButton = RadioButton(this).apply {
                id = level
                text = "$emoji $label"
                textSize = 16f
                setPadding(16, 16, 16, 16)
            }
            radioGroup.addView(radioButton)
        }
        
        // Set default selection to neutral
        radioGroup.check(3)
        
        AlertDialog.Builder(this)
            .setTitle("How are you feeling?")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val selectedMoodLevel = radioGroup.checkedRadioButtonId
                val note = editTextNote.text.toString().trim()
                
                if (selectedMoodLevel != -1) {
                    val selectedMood = moodOptions.find { it.third == selectedMoodLevel }
                    selectedMood?.let { (emoji, _, level) ->
                        preferencesManager.addMoodEntry(emoji, note, level)
                        loadMoodEntries()
                        Toast.makeText(this, "Mood entry saved! $emoji", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "Please select a mood", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showDeleteMoodDialog(moodEntry: MoodEntry) {
        AlertDialog.Builder(this)
            .setTitle("Delete Mood Entry")
            .setMessage("Are you sure you want to delete this mood entry?")
            .setPositiveButton("Delete") { _, _ ->
                preferencesManager.deleteMoodEntry(moodEntry.id)
                loadMoodEntries()
                Toast.makeText(this, "Mood entry deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onMoodLongClick(moodEntry: MoodEntry) {
        showDeleteMoodDialog(moodEntry)
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.mood_menu, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_add_mood -> {
                showAddMoodDialog()
                true
            }
            R.id.action_view_chart -> {
                showMoodTrendChart()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun showMoodTrendChart() {
        val intent = Intent(this, MoodChartActivity::class.java)
        startActivity(intent)
    }
}
