package com.wellnessapp.activities

import android.app.AlertDialog
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.wellnessapp.R
import com.wellnessapp.adapters.HabitAdapter
import com.wellnessapp.databinding.ActivityHabitTrackerBinding
import com.wellnessapp.models.Habit
import com.wellnessapp.utils.PreferencesManager
import com.wellnessapp.widgets.HabitWidgetProvider
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieData
import android.graphics.Color

/**
 * HabitTrackerActivity - Manages daily wellness habits
 * Features: Add, edit, delete habits and track completion status
 */
class HabitTrackerActivity : AppCompatActivity(), HabitAdapter.OnHabitInteractionListener {
    
    private lateinit var binding: ActivityHabitTrackerBinding
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var habitAdapter: HabitAdapter
    private var habits = mutableListOf<Habit>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHabitTrackerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferencesManager = PreferencesManager(this)
        
        setupToolbar()
        setupRecyclerView()
        setupFab()
        setupMiniPieChart()
        loadHabits()
        updateProgressDisplay()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Daily Habit Tracker"
    }
    
    private fun setupRecyclerView() {
        habitAdapter = HabitAdapter(habits, this)
        binding.recyclerViewHabits.apply {
            layoutManager = LinearLayoutManager(this@HabitTrackerActivity)
            adapter = habitAdapter
        }
    }
    
    private fun setupFab() {
        binding.fabAddHabit.setOnClickListener {
            showAddHabitDialog()
        }
    }
    
    private fun loadHabits() {
        habits.clear()
        habits.addAll(preferencesManager.getHabits())
        habitAdapter.notifyDataSetChanged()
        
        // Show empty state if no habits
        if (habits.isEmpty()) {
            binding.layoutEmptyState.visibility = android.view.View.VISIBLE
            binding.recyclerViewHabits.visibility = android.view.View.GONE
        } else {
            binding.layoutEmptyState.visibility = android.view.View.GONE
            binding.recyclerViewHabits.visibility = android.view.View.VISIBLE
        }
    }
    
    private fun updateProgressDisplay() {
        val completedCount = habits.count { it.isCompleted }
        val totalCount = habits.size
        val percentage = if (totalCount > 0) (completedCount * 100) / totalCount else 0
        
        binding.textProgress.text = "$completedCount of $totalCount habits completed"
        binding.progressBar.progress = percentage
        binding.textPercentage.text = "$percentage%"
        
        // Update mini pie chart
        updateMiniPieChart(completedCount, totalCount)
    }
    
    private fun setupMiniPieChart() {
        binding.miniPieChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawHoleEnabled(true)
            setHoleColor(Color.TRANSPARENT)
            setHoleRadius(40f)
            setDrawEntryLabels(false)
            setTouchEnabled(false)
        }
    }
    
    private fun updateMiniPieChart(completed: Int, total: Int) {
        if (total == 0) {
            binding.miniPieChart.visibility = android.view.View.GONE
            return
        }
        
        binding.miniPieChart.visibility = android.view.View.VISIBLE
        
        val entries = ArrayList<PieEntry>()
        if (completed > 0) {
            entries.add(PieEntry(completed.toFloat(), "Completed"))
        }
        if (total - completed > 0) {
            entries.add(PieEntry((total - completed).toFloat(), "Pending"))
        }
        
        val dataSet = PieDataSet(entries, "").apply {
            colors = listOf(
                Color.parseColor("#4CAF50"), // Green for completed
                Color.parseColor("#FF9800")  // Orange for pending
            )
            setDrawValues(false)
        }
        
        val data = PieData(dataSet)
        binding.miniPieChart.data = data
        binding.miniPieChart.invalidate()
    }
    
    private fun showAddHabitDialog() {
        val editText = EditText(this).apply {
            hint = "Enter habit name"
            setPadding(50, 30, 50, 30)
        }
        
        AlertDialog.Builder(this)
            .setTitle("Add New Habit")
            .setView(editText)
            .setPositiveButton("Add") { _, _ ->
                val habitName = editText.text.toString().trim()
                if (habitName.isNotEmpty()) {
                    preferencesManager.addHabit(habitName)
                    loadHabits()
                    updateProgressDisplay()
                    HabitWidgetProvider.updateAllWidgets(this)
                    Toast.makeText(this, "Habit added successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please enter a habit name", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun showDeleteHabitDialog(habit: Habit) {
        AlertDialog.Builder(this)
            .setTitle("Delete Habit")
            .setMessage("Are you sure you want to delete '${habit.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                preferencesManager.deleteHabit(habit.id)
                loadHabits()
                updateProgressDisplay()
                HabitWidgetProvider.updateAllWidgets(this)
                Toast.makeText(this, "Habit deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onHabitCheckedChanged(habit: Habit, isChecked: Boolean) {
        preferencesManager.updateHabitCompletion(habit.id, isChecked)
        
        // Update the local list
        val index = habits.indexOfFirst { it.id == habit.id }
        if (index != -1) {
            habits[index] = habits[index].copy(isCompleted = isChecked)
        }
        
        updateProgressDisplay()
        
        // Update widget
        HabitWidgetProvider.updateAllWidgets(this)
        
        val message = if (isChecked) {
            "Great job! Habit completed ✅"
        } else {
            "Habit unchecked"
        }
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
    
    override fun onHabitLongClick(habit: Habit) {
        showDeleteHabitDialog(habit)
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.habit_menu, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_reset_today -> {
                showResetTodayDialog()
                true
            }
            R.id.action_add_habit -> {
                showAddHabitDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun showResetTodayDialog() {
        AlertDialog.Builder(this)
            .setTitle("Reset Today's Progress")
            .setMessage("This will uncheck all habits for today. Are you sure?")
            .setPositiveButton("Reset") { _, _ ->
                // Reset all habits to uncompleted
                habits.forEachIndexed { index, habit ->
                    preferencesManager.updateHabitCompletion(habit.id, false)
                    habits[index] = habit.copy(isCompleted = false)
                }
                habitAdapter.notifyDataSetChanged()
                updateProgressDisplay()
                HabitWidgetProvider.updateAllWidgets(this)
                Toast.makeText(this, "Today's progress reset", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}