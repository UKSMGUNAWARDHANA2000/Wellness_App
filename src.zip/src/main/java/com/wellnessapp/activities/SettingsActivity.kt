package com.wellnessapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.wellnessapp.databinding.ActivitySettingsBinding
import com.wellnessapp.utils.HydrationReminderManager
import com.wellnessapp.utils.PreferencesManager

/**
 * SettingsActivity - Manages app settings and preferences
 */
class SettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var hydrationReminderManager: HydrationReminderManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferencesManager = PreferencesManager(this)
        hydrationReminderManager = HydrationReminderManager(this)
        
        setupToolbar()
        loadCurrentSettings()
        setupListeners()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"
    }
    
    private fun loadCurrentSettings() {
        // Load hydration settings
        binding.switchHydrationReminder.isChecked = preferencesManager.isHydrationReminderEnabled()
        binding.seekBarInterval.progress = (preferencesManager.getHydrationInterval() - 30) / 30 // Convert minutes to progress
        binding.seekBarWaterGoal.progress = preferencesManager.getDailyWaterGoal() - 1 // Convert glasses to progress
        
        updateIntervalText()
        updateWaterGoalText()
        
        // Load user name
        binding.editTextUserName.setText(preferencesManager.getUserName())
        
        // Update water intake display
        updateWaterIntakeDisplay()
    }
    
    private fun setupListeners() {
        // Hydration reminder toggle
        binding.switchHydrationReminder.setOnCheckedChangeListener { _, isChecked ->
            preferencesManager.setHydrationReminderEnabled(isChecked)
            if (isChecked) {
                hydrationReminderManager.scheduleHydrationReminders()
                Toast.makeText(this, "Hydration reminders enabled", Toast.LENGTH_SHORT).show()
            } else {
                hydrationReminderManager.cancelHydrationReminders()
                Toast.makeText(this, "Hydration reminders disabled", Toast.LENGTH_SHORT).show()
            }
        }
        
        // Hydration interval
        binding.seekBarInterval.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val intervalMinutes = (progress * 30) + 30 // 30 min to 8 hours
                    preferencesManager.setHydrationInterval(intervalMinutes)
                    updateIntervalText()
                    
                    // Reschedule reminders if enabled
                    if (preferencesManager.isHydrationReminderEnabled()) {
                        hydrationReminderManager.scheduleHydrationReminders()
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        
        // Water goal
        binding.seekBarWaterGoal.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val waterGoal = progress + 1 // 1 to 16 glasses
                    preferencesManager.setDailyWaterGoal(waterGoal)
                    updateWaterGoalText()
                }
            }
            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
        
        // Save user name
        binding.buttonSaveName.setOnClickListener {
            val userName = binding.editTextUserName.text.toString().trim()
            if (userName.isNotEmpty()) {
                preferencesManager.setUserName(userName)
                Toast.makeText(this, "Name saved!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter your name", Toast.LENGTH_SHORT).show()
            }
        }
        
        // Add water intake
        binding.buttonAddWater.setOnClickListener {
            hydrationReminderManager.recordWaterIntake()
            updateWaterIntakeDisplay()
            Toast.makeText(this, "Water intake recorded! 💧", Toast.LENGTH_SHORT).show()
        }
        
        // Reset daily progress
        binding.buttonResetDaily.setOnClickListener {
            showResetDailyDialog()
        }
    }
    
    private fun updateIntervalText() {
        val intervalMinutes = preferencesManager.getHydrationInterval()
        val text = when {
            intervalMinutes < 60 -> "${intervalMinutes} minutes"
            intervalMinutes == 60 -> "1 hour"
            intervalMinutes % 60 == 0 -> "${intervalMinutes / 60} hours"
            else -> "${intervalMinutes / 60}h ${intervalMinutes % 60}m"
        }
        binding.textIntervalValue.text = "Every $text"
    }
    
    private fun updateWaterGoalText() {
        val waterGoal = preferencesManager.getDailyWaterGoal()
        binding.textWaterGoalValue.text = "$waterGoal glasses per day"
    }
    
    private fun updateWaterIntakeDisplay() {
        val todayIntake = preferencesManager.getTodayWaterIntake()
        val dailyGoal = preferencesManager.getDailyWaterGoal()
        binding.textWaterIntakeToday.text = "Today: $todayIntake/$dailyGoal glasses"
        
        // Update progress
        val percentage = if (dailyGoal > 0) (todayIntake * 100) / dailyGoal else 0
        binding.progressWaterToday.progress = percentage.coerceAtMost(100)
    }
    
    private fun showResetDailyDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Reset Daily Progress")
            .setMessage("This will reset all habits and water intake for today. Are you sure?")
            .setPositiveButton("Reset") { _, _ ->
                preferencesManager.resetDailyProgress()
                updateWaterIntakeDisplay()
                Toast.makeText(this, "Daily progress reset", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}