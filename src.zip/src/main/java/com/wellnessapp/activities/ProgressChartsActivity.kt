package com.wellnessapp.activities

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.PercentFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.wellnessapp.R
import com.wellnessapp.databinding.ActivityProgressChartsBinding
import com.wellnessapp.utils.PreferencesManager

/**
 * ProgressChartsActivity - Comprehensive progress visualization with pie charts and bar graphs
 */
class ProgressChartsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityProgressChartsBinding
    private lateinit var preferencesManager: PreferencesManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProgressChartsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        preferencesManager = PreferencesManager(this)
        
        setupToolbar()
        setupCharts()
        loadProgressData()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Progress Analytics"
    }
    
    private fun setupCharts() {
        setupPieChart()
        setupBarChart()
        setupWeeklyBarChart()
    }
    
    private fun setupPieChart() {
        binding.pieChartHabits.apply {
            setUsePercentValues(true)
            description.isEnabled = false
            setExtraOffsets(5f, 10f, 5f, 5f)
            
            dragDecelerationFrictionCoef = 0.95f
            
            setDrawHoleEnabled(true)
            setHoleColor(Color.WHITE)
            setHoleRadius(35f)
            setTransparentCircleRadius(40f)
            
            setDrawCenterText(true)
            centerText = "Today's\nProgress"
            setCenterTextSize(16f)
            setCenterTextColor(Color.DKGRAY)
            
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            
            animateY(1400, Easing.EaseInOutQuad)
            
            legend.apply {
                verticalAlignment = Legend.LegendVerticalAlignment.TOP
                horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
                orientation = Legend.LegendOrientation.VERTICAL
                setDrawInside(false)
                xEntrySpace = 7f
                yEntrySpace = 0f
                yOffset = 0f
            }
            
            setEntryLabelColor(Color.WHITE)
            setEntryLabelTextSize(12f)
        }
    }
    
    private fun setupBarChart() {
        binding.barChartHabits.apply {
            description.isEnabled = false
            setMaxVisibleValueCount(60)
            setPinchZoom(false)
            setDrawBarShadow(false)
            setDrawGridBackground(false)
            
            xAxis.apply {
                position = com.github.mikephil.charting.components.XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                labelCount = 7
            }
            
            axisLeft.apply {
                setLabelCount(8, false)
                setPosition(com.github.mikephil.charting.components.YAxis.YAxisLabelPosition.OUTSIDE_CHART)
                spaceTop = 15f
                axisMinimum = 0f
                axisMaximum = 100f
            }
            
            axisRight.isEnabled = false
            
            legend.apply {
                verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
                horizontalAlignment = Legend.LegendHorizontalAlignment.LEFT
                orientation = Legend.LegendOrientation.HORIZONTAL
                setDrawInside(false)
                form = Legend.LegendForm.SQUARE
                formSize = 9f
                textSize = 11f
                xEntrySpace = 4f
            }
            
            animateY(1000)
        }
    }
    
    private fun setupWeeklyBarChart() {
        binding.barChartWeekly.apply {
            description.isEnabled = false
            setMaxVisibleValueCount(60)
            setPinchZoom(false)
            setDrawBarShadow(false)
            setDrawGridBackground(false)
            
            xAxis.apply {
                position = com.github.mikephil.charting.components.XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                labelCount = 7
            }
            
            axisLeft.apply {
                setLabelCount(8, false)
                setPosition(com.github.mikephil.charting.components.YAxis.YAxisLabelPosition.OUTSIDE_CHART)
                spaceTop = 15f
                axisMinimum = 0f
            }
            
            axisRight.isEnabled = false
            
            legend.apply {
                verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
                horizontalAlignment = Legend.LegendHorizontalAlignment.LEFT
                orientation = Legend.LegendOrientation.HORIZONTAL
                setDrawInside(false)
                form = Legend.LegendForm.SQUARE
                formSize = 9f
                textSize = 11f
                xEntrySpace = 4f
            }
            
            animateY(1000)
        }
    }
    
    private fun loadProgressData() {
        val habits = preferencesManager.getHabits()
        val completionPercentage = preferencesManager.getTodayHabitCompletion()
        
        setupHabitPieChart(habits, completionPercentage)
        setupHabitBarChart(habits)
        setupWeeklyProgressChart()
        updateStatistics(habits, completionPercentage)
    }
    
    private fun setupHabitPieChart(habits: List<com.wellnessapp.models.Habit>, completionPercentage: Int) {
        val entries = ArrayList<PieEntry>()
        
        if (habits.isNotEmpty()) {
            val completedCount = habits.count { it.isCompleted }
            val pendingCount = habits.size - completedCount
            
            if (completedCount > 0) {
                entries.add(PieEntry(completedCount.toFloat(), "Completed"))
            }
            if (pendingCount > 0) {
                entries.add(PieEntry(pendingCount.toFloat(), "Pending"))
            }
        } else {
            entries.add(PieEntry(1f, "No Habits Yet"))
        }
        
        val dataSet = PieDataSet(entries, "Habit Status").apply {
            setDrawIcons(false)
            sliceSpace = 3f
            iconsOffset = com.github.mikephil.charting.utils.MPPointF(0f, 40f)
            selectionShift = 5f
            
            colors = if (habits.isNotEmpty()) {
                listOf(
                    Color.parseColor("#4CAF50"), // Green for completed
                    Color.parseColor("#FF9800")  // Orange for pending
                )
            } else {
                listOf(Color.parseColor("#BDBDBD")) // Gray for no habits
            }
        }
        
        val data = PieData(dataSet).apply {
            setValueFormatter(PercentFormatter())
            setValueTextSize(11f)
            setValueTextColor(Color.WHITE)
        }
        
        binding.pieChartHabits.data = data
        binding.pieChartHabits.highlightValues(null)
        binding.pieChartHabits.invalidate()
    }
    
    private fun setupHabitBarChart(habits: List<com.wellnessapp.models.Habit>) {
        if (habits.isEmpty()) {
            binding.barChartHabits.visibility = android.view.View.GONE
            binding.textNoHabitsBar.visibility = android.view.View.VISIBLE
            return
        }
        
        binding.barChartHabits.visibility = android.view.View.VISIBLE
        binding.textNoHabitsBar.visibility = android.view.View.GONE
        
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()
        
        habits.forEachIndexed { index, habit ->
            val progress = if (habit.isCompleted) 100f else 0f
            entries.add(BarEntry(index.toFloat(), progress))
            labels.add(habit.name.take(10) + if (habit.name.length > 10) "..." else "")
        }
        
        val dataSet = BarDataSet(entries, "Habit Completion").apply {
            setDrawIcons(false)
            colors = habits.map { habit ->
                if (habit.isCompleted) Color.parseColor("#4CAF50") else Color.parseColor("#FF9800")
            }
            valueTextSize = 10f
            valueTextColor = Color.BLACK
        }
        
        val data = BarData(dataSet).apply {
            barWidth = 0.9f
            setValueFormatter(object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return if (value > 0) "✓" else "○"
                }
            })
        }
        
        binding.barChartHabits.data = data
        binding.barChartHabits.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return if (value.toInt() < labels.size) labels[value.toInt()] else ""
            }
        }
        binding.barChartHabits.invalidate()
    }
    
    private fun setupWeeklyProgressChart() {
        // Get last 7 days progress data
        val weeklyData = getWeeklyProgressData()
        
        val entries = ArrayList<BarEntry>()
        val labels = ArrayList<String>()
        
        weeklyData.forEachIndexed { index, (day, percentage) ->
            entries.add(BarEntry(index.toFloat(), percentage.toFloat()))
            labels.add(day)
        }
        
        val dataSet = BarDataSet(entries, "Weekly Progress %").apply {
            setDrawIcons(false)
            color = Color.parseColor("#2196F3")
            valueTextSize = 12f
            valueTextColor = Color.BLACK
        }
        
        val data = BarData(dataSet).apply {
            barWidth = 0.8f
            setValueFormatter(object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "${value.toInt()}%"
                }
            })
        }
        
        binding.barChartWeekly.data = data
        binding.barChartWeekly.xAxis.valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                return if (value.toInt() < labels.size) labels[value.toInt()] else ""
            }
        }
        binding.barChartWeekly.invalidate()
    }
    
    private fun getWeeklyProgressData(): List<Pair<String, Int>> {
        // Simulate weekly progress data - in real app, this would come from stored historical data
        val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        val currentProgress = preferencesManager.getTodayHabitCompletion()
        
        // For demo purposes, generate some sample data with today's actual progress
        return daysOfWeek.mapIndexed { index, day ->
            val progress = when {
                index == 6 -> currentProgress // Today (Sunday as last day)
                index >= 4 -> (60..90).random() // Recent days
                else -> (40..80).random() // Earlier days
            }
            Pair(day, progress)
        }
    }
    
    private fun updateStatistics(habits: List<com.wellnessapp.models.Habit>, completionPercentage: Int) {
        val completedCount = habits.count { it.isCompleted }
        val totalCount = habits.size
        val waterIntake = preferencesManager.getTodayWaterIntake()
        val waterGoal = preferencesManager.getDailyWaterGoal()
        val moodCount = preferencesManager.getMoodEntriesCount()
        
        val statsText = """
            📊 Today's Analytics Summary:
            
            ✅ Habits Completed: $completedCount/$totalCount ($completionPercentage%)
            💧 Hydration Progress: $waterIntake/$waterGoal glasses
            😊 Total Mood Entries: $moodCount
            🎯 Weekly Average: ${getWeeklyProgressData().map { it.second }.average().toInt()}%
        """.trimIndent()
        
        binding.textProgressStats.text = statsText
        binding.textProgressStats.visibility = android.view.View.VISIBLE
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}