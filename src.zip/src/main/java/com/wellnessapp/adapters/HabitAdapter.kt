package com.wellnessapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.wellnessapp.databinding.ItemHabitBinding
import com.wellnessapp.models.Habit

/**
 * HabitAdapter - RecyclerView adapter for displaying and managing habits
 */
class HabitAdapter(
    private val habits: List<Habit>,
    private val listener: OnHabitInteractionListener
) : RecyclerView.Adapter<HabitAdapter.HabitViewHolder>() {
    
    interface OnHabitInteractionListener {
        fun onHabitCheckedChanged(habit: Habit, isChecked: Boolean)
        fun onHabitLongClick(habit: Habit)
    }
    
    inner class HabitViewHolder(private val binding: ItemHabitBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(habit: Habit) {
            binding.apply {
                textHabitName.text = habit.name
                checkboxHabit.isChecked = habit.isCompleted
                
                // Set completion status styling
                if (habit.isCompleted) {
                    textHabitName.alpha = 0.6f
                    cardHabit.alpha = 0.8f
                } else {
                    textHabitName.alpha = 1.0f
                    cardHabit.alpha = 1.0f
                }
                
                // Handle checkbox changes
                checkboxHabit.setOnCheckedChangeListener { _, isChecked ->
                    listener.onHabitCheckedChanged(habit, isChecked)
                }
                
                // Handle long clicks for deletion
                cardHabit.setOnLongClickListener {
                    listener.onHabitLongClick(habit)
                    true
                }
                
                // Show creation date
                textDateCreated.text = "Created: ${habit.dateCreated}"
                
                // Show last completed date if available
                if (habit.lastCompletedDate != null && habit.isCompleted) {
                    textLastCompleted.text = "Last completed: ${habit.lastCompletedDate}"
                    textLastCompleted.visibility = android.view.View.VISIBLE
                } else {
                    textLastCompleted.visibility = android.view.View.GONE
                }
            }
        }
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitViewHolder {
        val binding = ItemHabitBinding.inflate(
            LayoutInflater.from(parent.context), 
            parent, 
            false
        )
        return HabitViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: HabitViewHolder, position: Int) {
        holder.bind(habits[position])
    }
    
    override fun getItemCount(): Int = habits.size
}