package com.wellnessapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.wellnessapp.databinding.ItemMoodBinding
import com.wellnessapp.models.MoodEntry
import java.text.SimpleDateFormat
import java.util.*

/**
 * MoodAdapter - RecyclerView adapter for displaying mood entries
 */
class MoodAdapter(
    private val moodEntries: List<MoodEntry>,
    private val listener: OnMoodInteractionListener
) : RecyclerView.Adapter<MoodAdapter.MoodViewHolder>() {
    
    interface OnMoodInteractionListener {
        fun onMoodLongClick(moodEntry: MoodEntry)
    }
    
    private val dateTimeFormat = SimpleDateFormat("MMM dd, yyyy 'at' HH:mm", Locale.getDefault())
    private val inputFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    
    inner class MoodViewHolder(private val binding: ItemMoodBinding) : 
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(moodEntry: MoodEntry) {
            binding.apply {
                textMoodEmoji.text = moodEntry.emoji
                textMoodNote.text = if (moodEntry.note.isNotEmpty()) {
                    moodEntry.note
                } else {
                    "No note added"
                }
                
                // Format and display timestamp
                try {
                    val date = inputFormat.parse(moodEntry.timestamp)
                    textMoodTimestamp.text = dateTimeFormat.format(date ?: Date())
                } catch (e: Exception) {
                    textMoodTimestamp.text = moodEntry.timestamp
                }
                
                // Set mood level indicator
                val moodLevelText = when (moodEntry.moodLevel) {
                    1 -> "Very Sad"
                    2 -> "Sad"
                    3 -> "Neutral"
                    4 -> "Happy"
                    5 -> "Very Happy"
                    else -> "Unknown"
                }
                textMoodLevel.text = moodLevelText
                
                // Set mood level color
                val moodColor = when (moodEntry.moodLevel) {
                    1 -> android.R.color.holo_red_dark
                    2 -> android.R.color.holo_orange_dark
                    3 -> android.R.color.darker_gray
                    4 -> android.R.color.holo_green_light
                    5 -> android.R.color.holo_green_dark
                    else -> android.R.color.darker_gray
                }
                textMoodLevel.setTextColor(
                    itemView.context.getColor(moodColor)
                )
                
                // Handle long clicks for deletion
                cardMood.setOnLongClickListener {
                    listener.onMoodLongClick(moodEntry)
                    true
                }
                
                // Set note visibility
                if (moodEntry.note.isEmpty()) {
                    textMoodNote.alpha = 0.6f
                } else {
                    textMoodNote.alpha = 1.0f
                }
            }
        }
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoodViewHolder {
        val binding = ItemMoodBinding.inflate(
            LayoutInflater.from(parent.context), 
            parent, 
            false
        )
        return MoodViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: MoodViewHolder, position: Int) {
        holder.bind(moodEntries[position])
    }
    
    override fun getItemCount(): Int = moodEntries.size
}