package com.wellnessapp.models

/**
 * MoodEntry data model representing a mood journal entry
 */
data class MoodEntry(
    val id: Int,
    val emoji: String,
    val note: String,
    val timestamp: String,
    val moodLevel: Int // 1-5 scale (1: Very Bad, 2: Bad, 3: Neutral, 4: Good, 5: Excellent)
)