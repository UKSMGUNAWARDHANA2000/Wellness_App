package com.wellnessapp.models

/**
 * Habit data model representing a daily wellness habit
 */
data class Habit(
    val id: Int,
    val name: String,
    val isCompleted: Boolean = false,
    val dateCreated: String,
    val lastCompletedDate: String? = null
)