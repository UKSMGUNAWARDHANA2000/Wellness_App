package com.wellnessapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.wellnessapp.activities.HabitTrackerActivity
import com.wellnessapp.activities.MoodJournalActivity
import com.wellnessapp.activities.SettingsActivity
import com.wellnessapp.databinding.ActivityMainBinding
import com.wellnessapp.utils.WellnessSensorManager
import com.wellnessapp.utils.PreferencesManager
import com.wellnessapp.utils.HydrationReminderManager
import com.wellnessapp.widgets.HabitWidgetProvider
import android.widget.Toast
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * MainActivity - The main dashboard of the Wellness App
 * Provides navigation to different features: Habit Tracker, Mood Journal, and Settings
 * Integrates with sensors for step counting and shake detection
 */
class MainActivity : AppCompatActivity(), WellnessSensorManager.SensorListener {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var hydrationReminderManager: HydrationReminderManager
    private lateinit var sensorManager: WellnessSensorManager
    
    companion object {
        private const val ACTIVITY_RECOGNITION_PERMISSION_CODE = 1001
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Initialize managers
        preferencesManager = PreferencesManager(this)
        hydrationReminderManager = HydrationReminderManager(this)
        sensorManager = WellnessSensorManager(this, this)
        
        setupToolbar()
        setupNavigationCards()
        updateDashboardStats()
        setupImages()
        setupSensors()
        
        // Set up hydration reminders if enabled
        if (preferencesManager.isHydrationReminderEnabled()) {
            hydrationReminderManager.scheduleHydrationReminders()
        }
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "Wellness Dashboard"
    }
    
    private fun setupNavigationCards() {
        // Habit Tracker Card
        binding.cardHabitTracker.setOnClickListener {
            startActivity(Intent(this, HabitTrackerActivity::class.java))
        }
        
        // Mood Journal Card
        binding.cardMoodJournal.setOnClickListener {
            startActivity(Intent(this, MoodJournalActivity::class.java))
        }
        
        // Progress Charts Card
        binding.cardProgressCharts.setOnClickListener {
            startActivity(Intent(this, com.wellnessapp.activities.ProgressChartsActivity::class.java))
        }
        
        // Settings Card
        binding.cardSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
    
    private fun updateDashboardStats() {
        // Update today's habit completion percentage
        val todayCompletion = preferencesManager.getTodayHabitCompletion()
        binding.textTodayProgress.text = "${todayCompletion}% completed today"
        binding.progressToday.progress = todayCompletion
        
        // Update total habits count
        val habitsCount = preferencesManager.getHabitsCount()
        binding.textTotalHabits.text = "$habitsCount habits tracked"
        
        // Update mood entries count
        val moodEntriesCount = preferencesManager.getMoodEntriesCount()
        binding.textMoodEntries.text = "$moodEntriesCount mood entries"
        
        // Update hydration status
        val isHydrationEnabled = preferencesManager.isHydrationReminderEnabled()
        binding.textHydrationStatus.text = if (isHydrationEnabled) {
            "Hydration reminders: ON"
        } else {
            "Hydration reminders: OFF"
        }
    }
    
    override fun onResume() {
        super.onResume()
        // Refresh dashboard when returning from other activities
        updateDashboardStats()
        
        // Update widget
        HabitWidgetProvider.updateAllWidgets(this)
        
        // Start sensor listening
        sensorManager.startListening()
    }
    
    override fun onPause() {
        super.onPause()
        // Stop sensor listening to save battery
        sensorManager.stopListening()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_progress_charts -> {
                startActivity(Intent(this, com.wellnessapp.activities.ProgressChartsActivity::class.java))
                true
            }
            R.id.action_share -> {
                shareAppStats()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun shareAppStats() {
        val todayCompletion = preferencesManager.getTodayHabitCompletion()
        val habitsCount = preferencesManager.getHabitsCount()
        val moodEntriesCount = preferencesManager.getMoodEntriesCount()
        
        val shareText = """
            🌟 My Wellness Journey Today 🌟
            
            ✅ Today's Habits: ${todayCompletion}% completed
            📊 Total Habits Tracked: $habitsCount
            😊 Mood Entries: $moodEntriesCount
            
            Stay healthy and mindful! #WellnessApp #HealthyLiving
        """.trimIndent()
        
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        
        startActivity(Intent.createChooser(shareIntent, "Share your wellness progress"))
    }
    
    private fun setupSensors() {
        // Check for activity recognition permission
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACTIVITY_RECOGNITION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                ACTIVITY_RECOGNITION_PERMISSION_CODE
            )
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            ACTIVITY_RECOGNITION_PERMISSION_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Sensor features enabled!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Sensor features require permission", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // Sensor listener implementations
    override fun onStepDetected(totalSteps: Int) {
        // Update step count in preferences or display
        // This could be used to automatically complete "Take 10,000 steps" habit
        runOnUiThread {
            if (totalSteps >= 10000) {
                // Auto-complete step habit if it exists
                val habits = preferencesManager.getHabits()
                val stepHabit = habits.find { it.name.contains("steps", ignoreCase = true) }
                stepHabit?.let { habit ->
                    if (!habit.isCompleted) {
                        preferencesManager.updateHabitCompletion(habit.id, true)
                        updateDashboardStats()
                        HabitWidgetProvider.updateAllWidgets(this)
                        Toast.makeText(this, "Great! Step goal achieved! ✅", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }
    
    override fun onShakeDetected() {
        // Show quick mood entry dialog
        runOnUiThread {
            Toast.makeText(this, "Shake detected! Quick mood entry", Toast.LENGTH_SHORT).show()
            showQuickMoodDialog()
        }
    }
    
    private fun showQuickMoodDialog() {
        val moods = arrayOf("😭 Very Sad", "😢 Sad", "😐 Neutral", "😊 Happy", "😄 Very Happy")
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Quick Mood Check")
            .setItems(moods) { _, which ->
                val moodLevel = which + 1
                val emoji = moods[which].split(" ")[0]
                preferencesManager.addMoodEntry(emoji, "Quick entry via shake", moodLevel)
                updateDashboardStats()
                Toast.makeText(this, "Mood logged! $emoji", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun setupImages() {
        // Set hero image programmatically if needed
        // binding.imageHeroWellness.setImageResource(R.drawable.your_custom_hero)
        
        // You can also load images from assets or external sources
        // Glide.with(this).load("your_image_url").into(binding.imageHeroWellness)
    }
}
